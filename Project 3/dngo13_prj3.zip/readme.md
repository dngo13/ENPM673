ENPM Project 3 Read me
Diane Ngo
Spring 2021

Requires Python3.7, OpenCV 4.2, NumPy, OS, matplotlib
1. Unzip dngo13_prj3.zip
2. Open IDE (preferred Spyder)
3. Import prj3.py
4. Press play/run
5. File will prompt for dataset 1, 2, or 3
6. Output files will be saved in the working directory

IMPORTANT NOTE: the program calculates 8 random points for some calculations. You may need to keep restarting the program if there is an error with essential matrix. Some results will be better than others.